from knowledge.retriever import Retriever

def index_all(chunks):
    r = Retriever()
    r.add(chunks)
    return r