def chunk_text(data):
    chunks = []

    for page in data:
        parts = page["text"].split("\n\n")
        for p in parts:
            if len(p.strip()) > 50:
                chunks.append(p)

    return chunks