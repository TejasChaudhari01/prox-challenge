import pdfplumber

def extract_tables(pdf):
    tables = []

    with pdfplumber.open(pdf) as doc:
        for p in doc.pages:
            tables += p.extract_tables()

    return tables