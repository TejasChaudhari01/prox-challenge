from ingestion.pdf_parser import parse_pdf
from ingestion.chunker import chunk_text
from ingestion.indexer import index_all

PDFS = [
    "knowledge/raw_docs/owner-manual.pdf",
    "knowledge/raw_docs/quick-start-guide.pdf",
    "knowledge/raw_docs/selection-chart.pdf"
]

def run():
    all_chunks = []

    for pdf in PDFS:
        text, _ = parse_pdf(pdf, "knowledge/images")
        chunks = chunk_text(text)
        all_chunks.extend(chunks)

    index_all(all_chunks)
    print("✅ Ingestion complete")

if __name__ == "__main__":
    run()