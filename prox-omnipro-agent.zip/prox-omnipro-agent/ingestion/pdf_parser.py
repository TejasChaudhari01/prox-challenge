import fitz, os

def parse_pdf(path, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    doc = fitz.open(path)

    text_data = []
    images = []

    for i, page in enumerate(doc):
        text_data.append({"page": i, "text": page.get_text()})

        for img_i, img in enumerate(page.get_images(full=True)):
            xref = img[0]
            base = doc.extract_image(xref)
            path_img = f"{out_dir}/p{i}_{img_i}.png"

            with open(path_img, "wb") as f:
                f.write(base["image"])

            images.append(path_img)

    return text_data, images