from fastapi import FastAPI, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse

from agent.core import OmniAgent
from tools.registry import TOOLS
from knowledge.retriever import Retriever

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

retriever = Retriever()
agent = OmniAgent(retriever, TOOLS)


@app.get("/")
def home():
    return HTMLResponse("""
    <html>
      <head><title>OmniPro 220 Assistant API</title></head>
      <body style="font-family: Arial; padding: 40px;">
        <h2>OmniPro 220 Assistant API</h2>
        <p>API is running.</p>
        <p>Open <a href="/docs">/docs</a> to test endpoints.</p>
      </body>
    </html>
    """)


@app.post("/chat")
async def chat(payload: dict):
    query = payload.get("query", "")
    return {"response": agent.run(query)}


@app.post("/image")
async def image(file: UploadFile):
    img = await file.read()
    return {"response": agent.run("analyze weld image", image=img)}