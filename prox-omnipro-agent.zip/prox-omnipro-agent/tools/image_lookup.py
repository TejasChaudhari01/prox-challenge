from pathlib import Path

IMAGE_DIR = Path("knowledge/images")

def image_lookup(query):
    """
    Very simple image lookup by keyword.
    Assumes ingestion has extracted images into knowledge/images.
    """
    q = query.lower()

    if not IMAGE_DIR.exists():
        return {
            "type": "text",
            "content": "No extracted manual images were found."
        }

    matches = []

    for img in IMAGE_DIR.glob("*"):
        name = img.name.lower()

        if "tig" in q and ("tig" in name or "p" in name):
            matches.append(str(img).replace("\\", "/"))
        elif "wire" in q and "wire" in name:
            matches.append(str(img).replace("\\", "/"))
        elif "front" in q and "front" in name:
            matches.append(str(img).replace("\\", "/"))
        elif "panel" in q and "panel" in name:
            matches.append(str(img).replace("\\", "/"))
        elif "weld" in q and "weld" in name:
            matches.append(str(img).replace("\\", "/"))

    if not matches:
        # fallback: return first extracted image if any
        any_images = list(IMAGE_DIR.glob("*"))
        if any_images:
            matches = [str(any_images[0]).replace("\\", "/")]

    if not matches:
        return {
            "type": "text",
            "content": "No relevant manual image found."
        }

    return {
        "type": "image_gallery",
        "content": matches[:4]
    }