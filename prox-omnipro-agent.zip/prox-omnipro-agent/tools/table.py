def table(query=None):
    return {
        "type": "table",
        "content": [
            ["Process", "Voltage", "Amperage", "Duty Cycle"],
            ["MIG", "120V", "125A", "20%"],
            ["MIG", "240V", "200A", "40%"]
        ]
    }