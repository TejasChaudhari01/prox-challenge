from pathlib import Path

def evidence(query, context_chunks=None):
    """
    Return lightweight evidence metadata the UI can render.
    """
    snippets = []

    if context_chunks:
        for idx, chunk in enumerate(context_chunks[:3], start=1):
            snippets.append({
                "source": f"Manual chunk {idx}",
                "page": idx,
                "snippet": str(chunk)[:350]
            })

    if not snippets:
        snippets = [
            {
                "source": "Owner's Manual",
                "page": 1,
                "snippet": f"No exact evidence chunk was passed for query: {query}"
            }
        ]

    return {
        "type": "evidence",
        "content": snippets
    }