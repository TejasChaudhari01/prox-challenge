def diagram(query):
    q = query.lower()

    if "tig" in q:
        return {
            "type": "diagram",
            "content": """
<div style="padding:16px;">
  <h3 style="margin:0 0 12px 0;">TIG Polarity Setup (DCEN)</h3>
  <svg width="420" height="180" viewBox="0 0 420 180" xmlns="http://www.w3.org/2000/svg">
    <rect x="150" y="50" width="120" height="80" rx="12" fill="#1e293b" stroke="#60a5fa" stroke-width="2"/>
    <text x="210" y="80" text-anchor="middle" fill="#e2e8f0" font-size="14">OmniPro 220</text>
    <text x="175" y="110" fill="#22c55e" font-size="14">(-) Torch</text>
    <text x="175" y="128" fill="#ef4444" font-size="14">(+) Ground Clamp</text>

    <circle cx="60" cy="90" r="28" fill="#2563eb"/>
    <text x="60" y="95" text-anchor="middle" fill="white" font-size="12">Torch</text>

    <circle cx="360" cy="90" r="28" fill="#dc2626"/>
    <text x="360" y="95" text-anchor="middle" fill="white" font-size="11">Workpiece</text>

    <line x1="88" y1="90" x2="150" y2="90" stroke="#22c55e" stroke-width="4"/>
    <line x1="270" y1="115" x2="332" y2="90" stroke="#ef4444" stroke-width="4"/>

    <text x="100" y="78" fill="#22c55e" font-size="12">Negative lead</text>
    <text x="275" y="78" fill="#ef4444" font-size="12">Positive lead</text>
  </svg>
  <p style="margin-top:10px;">For TIG, connect the torch to the negative terminal and the ground clamp to the positive terminal.</p>
</div>
"""
        }

    return {
        "type": "diagram",
        "content": """
<div style="padding:16px;">
  <h3 style="margin:0 0 12px 0;">Polarity / Wiring Setup</h3>
  <p>Check the selected welding process, then match torch and ground clamp connections to the machine terminals.</p>
</div>
"""
    }