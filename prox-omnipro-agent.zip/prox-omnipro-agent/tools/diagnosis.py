def diagnosis(image=None):
    return {
        "type": "text",
        "content": """Likely issue: Porosity

What to check:
1. Contaminated or dirty base metal
2. Poor shielding gas coverage
3. Excessive wind blowing gas away
4. Incorrect gun angle or travel speed

What to do:
- Clean the metal thoroughly
- Check gas flow rate and hose connections
- Shield the weld area from airflow
- Keep a steady travel angle and consistent stickout
"""
    }