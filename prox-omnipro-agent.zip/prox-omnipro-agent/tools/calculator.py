def calculator(query):
    return {
        "type": "config",
        "content": {
            "material": "Mild Steel",
            "thickness": "1/4 in",
            "recommended_voltage": "22V",
            "wire_speed": "300 IPM",
            "notes": "Fine-tune based on bead profile and arc stability."
        }
    }