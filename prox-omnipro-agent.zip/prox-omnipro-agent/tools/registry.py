from tools.diagram import diagram
from tools.table import table
from tools.diagnosis import diagnosis
from tools.calculator import calculator
from tools.evidence import evidence
from tools.image_lookup import image_lookup

TOOLS = {
    "diagram": diagram,
    "table": table,
    "diagnosis": diagnosis,
    "calculator": calculator,
    "evidence": evidence,
    "image_lookup": image_lookup,
}