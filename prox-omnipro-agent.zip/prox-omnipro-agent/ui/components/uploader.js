export async function uploadImageFile(apiBase, file) {
  const formData = new FormData();
  formData.append("file", file);

  const res = await fetch(`${apiBase}/image`, {
    method: "POST",
    body: formData
  });

  if (!res.ok) {
    throw new Error(`Upload failed: ${res.status}`);
  }

  return res.json();
}