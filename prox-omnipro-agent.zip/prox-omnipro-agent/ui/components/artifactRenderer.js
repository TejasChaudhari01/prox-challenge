export function renderTool(tool) {
  if (!tool || typeof tool !== "object") return null;

  const card = document.createElement("div");
  card.className = "tool-card";

  const title = document.createElement("div");
  title.className = "tool-title";
  card.appendChild(title);

  if (tool.type === "diagram") {
    title.textContent = "Visual Setup";
    const wrap = document.createElement("div");
    wrap.className = "diagram-wrap";
    wrap.innerHTML = tool.content;
    card.appendChild(wrap);
    return card;
  }

  if (tool.type === "table") {
    title.textContent = "Reference Table";
    const table = document.createElement("table");

    tool.content.forEach((row, rowIndex) => {
      const tr = document.createElement("tr");
      row.forEach((cell) => {
        const el = document.createElement(rowIndex === 0 ? "th" : "td");
        el.textContent = cell;
        tr.appendChild(el);
      });
      table.appendChild(tr);
    });

    card.appendChild(table);
    return card;
  }

  if (tool.type === "config") {
    title.textContent = "Recommended Settings";
    const list = document.createElement("ul");
    list.className = "config-list";

    Object.entries(tool.content).forEach(([key, value]) => {
      const li = document.createElement("li");
      li.innerHTML = `<strong>${escapeHtml(key)}:</strong> ${escapeHtml(String(value))}`;
      list.appendChild(li);
    });

    card.appendChild(list);
    return card;
  }

  if (tool.type === "image") {
    title.textContent = "Reference Image";
    const img = document.createElement("img");
    img.className = "preview-image";
    img.src = `../${tool.content}`;
    img.alt = "Reference image";
    card.appendChild(img);
    return card;
  }

  if (tool.type === "image_gallery") {
    title.textContent = "Reference Images";
    const grid = document.createElement("div");
    grid.className = "image-grid";

    tool.content.forEach((path) => {
      const img = document.createElement("img");
      img.className = "preview-image";
      img.src = `../${path}`;
      img.alt = "Reference image";
      grid.appendChild(img);
    });

    card.appendChild(grid);
    return card;
  }

  if (tool.type === "evidence") {
    title.textContent = "Manual Evidence";
    const list = document.createElement("div");
    list.className = "evidence-list";

    tool.content.forEach((item) => {
      const block = document.createElement("div");
      block.className = "evidence-item";
      block.innerHTML = `
        <div class="evidence-meta">${escapeHtml(item.source)} · page ${escapeHtml(String(item.page))}</div>
        <div class="evidence-snippet">${escapeHtml(item.snippet)}</div>
      `;
      list.appendChild(block);
    });

    card.appendChild(list);
    return card;
  }

  title.textContent = "Tool Output";
  const body = document.createElement("div");
  body.className = "message-content";
  body.innerHTML = formatText(tool.content || JSON.stringify(tool));
  card.appendChild(body);
  return card;
}

export function formatText(text) {
  return escapeHtml(String(text))
    .replace(/`([^`]+)`/g, '<code class="inline-code">$1</code>')
    .replace(/\n/g, "<br>");
}

export function escapeHtml(text) {
  return String(text)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}