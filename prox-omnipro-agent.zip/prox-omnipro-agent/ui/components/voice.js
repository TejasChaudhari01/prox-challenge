export function createVoiceController({ inputEl, onTranscript, onSpeakStateChange }) {
  const SpeechRecognition =
    window.SpeechRecognition || window.webkitSpeechRecognition;

  let recognition = null;
  let listening = false;
  let speaking = false;

  if (SpeechRecognition) {
    recognition = new SpeechRecognition();
    recognition.lang = "en-US";
    recognition.interimResults = false;
    recognition.continuous = false;

    recognition.onstart = () => {
      listening = true;
      onSpeakStateChange?.({ listening, speaking });
    };

    recognition.onend = () => {
      listening = false;
      onSpeakStateChange?.({ listening, speaking });
    };

    recognition.onerror = () => {
      listening = false;
      onSpeakStateChange?.({ listening, speaking });
    };

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      if (inputEl) inputEl.value = transcript;
      onTranscript?.(transcript);
    };
  }

  function startListening() {
    if (recognition && !listening) recognition.start();
  }

  function stopListening() {
    if (recognition && listening) recognition.stop();
  }

  function speak(text) {
    if (!("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "en-US";

    utterance.onstart = () => {
      speaking = true;
      onSpeakStateChange?.({ listening, speaking });
    };

    utterance.onend = () => {
      speaking = false;
      onSpeakStateChange?.({ listening, speaking });
    };

    utterance.onerror = () => {
      speaking = false;
      onSpeakStateChange?.({ listening, speaking });
    };

    window.speechSynthesis.speak(utterance);
  }

  function stopSpeaking() {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      speaking = false;
      onSpeakStateChange?.({ listening, speaking });
    }
  }

  function isSupported() {
    return Boolean(SpeechRecognition || "speechSynthesis" in window);
  }

  return {
    startListening,
    stopListening,
    speak,
    stopSpeaking,
    isSupported,
  };
}