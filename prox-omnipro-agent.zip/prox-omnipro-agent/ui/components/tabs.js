export function createTabs(tabButtonsSelector, tabPanelsSelector, activeClass = "active") {
  const buttons = Array.from(document.querySelectorAll(tabButtonsSelector));
  const panels = Array.from(document.querySelectorAll(tabPanelsSelector));

  function activate(tabName) {
    buttons.forEach((btn) => {
      btn.classList.toggle(activeClass, btn.dataset.tab === tabName);
    });

    panels.forEach((panel) => {
      panel.classList.toggle(activeClass, panel.dataset.panel === tabName);
    });
  }

  buttons.forEach((btn) => {
    btn.addEventListener("click", () => activate(btn.dataset.tab));
  });

  if (buttons.length) activate(buttons[0].dataset.tab);

  return { activate };
}