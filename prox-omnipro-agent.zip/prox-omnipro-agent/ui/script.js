import { renderTool, formatText, escapeHtml } from "./components/artifactRenderer.js";
import { createVoiceController } from "./components/voice.js";
import { createTabs } from "./components/tabs.js";
import { uploadImageFile } from "./components/uploader.js";

const API_BASE = "http://127.0.0.1:8000";

const chat = document.getElementById("chat");
const queryInput = document.getElementById("query");
const askBtn = document.getElementById("askBtn");
const uploadBtn = document.getElementById("uploadBtn");
const fileInput = document.getElementById("imgUpload");
const emptyState = document.getElementById("emptyState");
const artifactContent = document.getElementById("artifactContent");
const evidenceContent = document.getElementById("evidenceContent");
const voiceBtn = document.getElementById("voiceBtn");
const speakBtn = document.getElementById("speakBtn");

createTabs(".tab-btn", ".tab-panel");

document.querySelectorAll(".prompt-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    queryInput.value = btn.dataset.prompt || "";
    queryInput.focus();
  });
});

const voice = createVoiceController({
  inputEl: queryInput,
  onTranscript: () => {},
  onSpeakStateChange: ({ listening, speaking }) => {
    voiceBtn.textContent = listening ? "🛑 Stop Voice" : "🎙 Start Voice";
    speakBtn.textContent = speaking ? "🔇 Stop Speaking" : "🔊 Speak Reply";
  }
});

voiceBtn.addEventListener("click", () => {
  if (voiceBtn.textContent.includes("Stop")) {
    voice.stopListening();
  } else {
    voice.startListening();
  }
});

let lastAssistantText = "";

speakBtn.addEventListener("click", () => {
  if (speakBtn.textContent.includes("Stop")) {
    voice.stopSpeaking();
  } else if (lastAssistantText) {
    voice.speak(lastAssistantText);
  }
});

askBtn.addEventListener("click", ask);
uploadBtn.addEventListener("click", uploadImage);

queryInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    ask();
  }
});

async function ask() {
  const query = queryInput.value.trim();
  if (!query) return;

  hideEmptyState();
  clearArtifactPanels();

  appendMessage("user", escapeHtml(query));
  const loadingId = appendLoading();

  try {
    const res = await fetch(`${API_BASE}/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query })
    });

    const data = await res.json();
    removeLoading(loadingId);
    renderAssistantPayload(data.response);
    queryInput.value = "";
    scrollToBottom();
  } catch (err) {
    removeLoading(loadingId);
    appendMessage("assistant", `Error: ${escapeHtml(err.message)}`);
  }
}

async function uploadImage() {
  const file = fileInput.files[0];
  if (!file) return;

  hideEmptyState();
  clearArtifactPanels();

  appendMessage("user", `Uploaded image: ${escapeHtml(file.name)}`);
  const loadingId = appendLoading("Analyzing image...");

  try {
    const data = await uploadImageFile(API_BASE, file);
    removeLoading(loadingId);
    renderAssistantPayload(data.response);
    fileInput.value = "";
    scrollToBottom();
  } catch (err) {
    removeLoading(loadingId);
    appendMessage("assistant", `Error: ${escapeHtml(err.message)}`);
  }
}

function renderAssistantPayload(payload) {
  if (!payload) {
    appendMessage("assistant", "No response received.");
    return;
  }

  const answer = payload.content || payload.response || JSON.stringify(payload);
  lastAssistantText = String(answer);
  appendMessage("assistant", formatText(answer));

  if (payload.tools && Array.isArray(payload.tools)) {
    payload.tools.forEach((tool) => {
      const node = renderTool(tool);
      if (!node) return;

      if (tool.type === "evidence") {
        evidenceContent.appendChild(node);
      } else {
        artifactContent.appendChild(node);
      }
    });
  }
}

function appendMessage(role, htmlText) {
  const wrapper = document.createElement("div");
  wrapper.className = `message-row ${role}`;

  const bubble = document.createElement("div");
  bubble.className = "message-bubble";

  const roleEl = document.createElement("div");
  roleEl.className = "message-role";
  roleEl.textContent = role === "user" ? "You" : "Assistant";

  const content = document.createElement("div");
  content.className = "message-content";
  content.innerHTML = htmlText;

  bubble.appendChild(roleEl);
  bubble.appendChild(content);
  wrapper.appendChild(bubble);
  chat.appendChild(wrapper);
  scrollToBottom();
}

function appendLoading(text = "Thinking...") {
  const id = `loading-${Date.now()}`;
  const wrapper = document.createElement("div");
  wrapper.className = "message-row assistant";
  wrapper.id = id;

  const bubble = document.createElement("div");
  bubble.className = "message-bubble";

  const role = document.createElement("div");
  role.className = "message-role";
  role.textContent = "Assistant";

  const content = document.createElement("div");
  content.className = "message-content loading-text";
  content.textContent = text;

  bubble.appendChild(role);
  bubble.appendChild(content);
  wrapper.appendChild(bubble);
  chat.appendChild(wrapper);
  scrollToBottom();

  return id;
}

function removeLoading(id) {
  const node = document.getElementById(id);
  if (node) node.remove();
}

function hideEmptyState() {
  if (emptyState) emptyState.style.display = "none";
}

function clearArtifactPanels() {
  artifactContent.innerHTML = `<div class="artifact-placeholder">Rendered diagrams, tables, images, and settings will appear here.</div>`;
  evidenceContent.innerHTML = `<div class="artifact-placeholder">Manual snippets and evidence will appear here.</div>`;
}

function scrollToBottom() {
  chat.scrollTop = chat.scrollHeight;
}