import chromadb

class Retriever:
    def __init__(self):
        self.client = chromadb.Client()
        self.collection = self.client.create_collection("omnipro")

    def add(self, docs):
        for i, d in enumerate(docs):
            self.collection.add(documents=[d], ids=[str(i)])

    def search(self, query):
        result = self.collection.query(query_texts=[query], n_results=3)
        return result["documents"]