import os
from dotenv import load_dotenv
import anthropic

from agent.prompt import SYSTEM_PROMPT
from agent.planner import plan

load_dotenv()

API_KEY = os.getenv("ANTHROPIC_API_KEY")

if not API_KEY:
    raise ValueError("ANTHROPIC_API_KEY not found. Add it to your .env file.")

client = anthropic.Anthropic(api_key=API_KEY)


def flatten_to_strings(item):
    if isinstance(item, list):
        return "\n".join(flatten_to_strings(i) for i in item)
    if isinstance(item, dict):
        return str(item)
    return str(item)


class OmniAgent:
    def __init__(self, retriever, tools):
        self.retriever = retriever
        self.tools = tools
        self.client = client

    def run(self, query, image=None):
        try:
            context_chunks = self.retriever.search(query)
            if context_chunks:
                context = "\n\n".join(flatten_to_strings(chunk) for chunk in context_chunks)
            else:
                context = "No relevant context found."

            steps = plan(query, image)

            tool_outputs = []
            for step in steps:
                tool_name = step.get("tool")
                args = step.get("args", {})

                if tool_name in self.tools:
                    result = self.tools[tool_name](**args)
                    tool_outputs.append(result)
                else:
                    tool_outputs.append({
                        "type": "text",
                        "content": f"[Unknown tool: {tool_name}]"
                    })

            tool_text = "\n\n".join(
                flatten_to_strings(output.get("content", output)) if isinstance(output, dict) else flatten_to_strings(output)
                for output in tool_outputs
            ) if tool_outputs else "No tools used."

            response = self.client.messages.create(
                model="claude-haiku-4-5-20251001",
                max_tokens=1000,
                system=SYSTEM_PROMPT,
                messages=[
                    {
                        "role": "user",
                        "content": f"""
You are helping a user operate a Vulcan OmniPro 220 welder.

User Question:
{query}

Relevant Manual Context:
{context}

Tool Outputs:
{tool_text}

Instructions:
- Be clear and practical
- Use step-by-step guidance for setup
- If troubleshooting, list causes and fixes
- If diagrams, tables, or images are available, reference them clearly
"""
                    }
                ]
            )

            return {
                "type": "text",
                "content": response.content[0].text,
                "tools": tool_outputs
            }

        except Exception as e:
            return {
                "type": "text",
                "content": f"Error: {str(e)}",
                "tools": []
            }