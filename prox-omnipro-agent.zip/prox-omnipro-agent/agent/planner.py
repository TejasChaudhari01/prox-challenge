def plan(query, image):
    q = query.lower()

    steps = []

    if "tig" in q and ("polarity" in q or "wiring" in q or "setup" in q):
        steps.append({"tool": "diagram", "args": {"query": query}})
        steps.append({"tool": "image_lookup", "args": {"query": query}})
        steps.append({"tool": "evidence", "args": {"query": query}})
        return steps

    if "duty cycle" in q:
        steps.append({"tool": "table", "args": {"query": query}})
        steps.append({"tool": "evidence", "args": {"query": query}})
        return steps

    if image:
        steps.append({"tool": "diagnosis", "args": {"image": image}})
        return steps

    if "settings" in q or "steel" in q or "thickness" in q:
        steps.append({"tool": "calculator", "args": {"query": query}})
        steps.append({"tool": "evidence", "args": {"query": query}})
        return steps

    if "image" in q or "show me" in q or "manual" in q:
        steps.append({"tool": "image_lookup", "args": {"query": query}})
        return steps

    return []